package listeners;

import classes2.Matrix;

public interface IMatrixListener {
	void matrixUpdated(Matrix matrix);
}
